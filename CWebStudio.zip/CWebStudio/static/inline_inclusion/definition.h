#include "recursion_protection/definition.h"

#include "inline_inclusion/inline_inclusion.c"