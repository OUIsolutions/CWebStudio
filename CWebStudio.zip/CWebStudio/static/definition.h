#include "smart_cache/smart_cache.c"
#include "inline_inclusion/definition.h"
#include "static/static.c"