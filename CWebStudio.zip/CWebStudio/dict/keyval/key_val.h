

typedef struct CwebKeyVal{
    char *key;
    char *value;

}CwebKeyVal;

struct CwebKeyVal* newCwebKeyVal(const char *key, const  char *value);
void CwebKeyVal_represent(struct CwebKeyVal *self);
void CwebKeyVal_free(struct CwebKeyVal *self);
