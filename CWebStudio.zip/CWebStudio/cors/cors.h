


void  private_cweb_generate_cors_response(struct CwebHttpResponse *response);