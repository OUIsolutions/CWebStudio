


void private_cweb_send_error_mensage( const char*mensage,int status_code, int socket);


void private_cweb_treat_response(int new_socket);


void private_cweb_handle_child_termination(int signal);