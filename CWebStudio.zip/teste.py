import socket

def send_raw_request(host, port, request):
    # Cria um socket TCP
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    try:
        # Conecta ao servidor local
        client_socket.connect((host, port))

        # Envia a requisição HTTP
        client_socket.sendall(request.encode())

        # Recebe a resposta
        response = b""
        while True:
            data = client_socket.recv(4096)
            if not data:
                break
            response += data

        # Imprime a resposta (pode ser tratada de outra forma, se necessário)
        print(response.decode())

    except socket.error as e:
        print(f"Erro ao enviar a requisição: {e}")

    finally:
        # Fecha o socket
        client_socket.close()

# Exemplo de uso
if __name__ == "__main__":
    host = "localhost"  # Endereço local
    port = 5000  # Porta do servidor local
    r = 'a' *2600
    # Monta a requisição HTTP pura com o header e o método desejados
    request = (
        f"GET /caminho-da-requisicao/?&{r}={r} HTTP/1.1\r\n\r\r"
        "Host:: " + host + "\r\r"
        "User-Agent: Meu Fuzzer\r\n"
        "Content-Type: text/plain\r\n"  # Substitua pelo tipo de conteúdo que deseja enviar
        "\r\n"
        "Conteúdo da requisição"  # Corpo da requisição (opcional)
    )

    send_raw_request(host, port, request)
